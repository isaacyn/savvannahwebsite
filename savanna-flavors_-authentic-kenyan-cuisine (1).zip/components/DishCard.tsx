
import React, { useState } from 'react';
import { Dish } from '../types';
import { geminiService } from '../services/geminiService';

interface DishCardProps {
  dish: Dish;
}

const DishCard: React.FC<DishCardProps> = ({ dish }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLearnMore = async () => {
    if (insight) return;
    setLoading(true);
    const text = await geminiService.getDishInsight(dish.name);
    setInsight(text || "No details available.");
    setLoading(false);
  };

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-300 border border-stone-100 flex flex-col">
      <div className="relative h-64 overflow-hidden group">
        <img 
          src={dish.imageUrl} 
          alt={dish.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 right-4 bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-bold">
          {dish.price}
        </div>
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="mb-2">
          <span className="text-xs font-semibold tracking-wider text-orange-600 uppercase">{dish.category}</span>
          <h3 className="text-xl font-bold text-stone-900 mt-1">{dish.name}</h3>
        </div>
        
        <p className="text-stone-600 text-sm mb-4 line-clamp-2">
          {dish.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {dish.ingredients.slice(0, 3).map((ing, i) => (
            <span key={i} className="text-[10px] bg-stone-100 text-stone-500 px-2 py-1 rounded">
              {ing}
            </span>
          ))}
        </div>

        <div className="mt-auto">
          {!insight ? (
            <button 
              onClick={handleLearnMore}
              disabled={loading}
              className="w-full py-2 bg-stone-900 text-white text-sm font-medium rounded-lg hover:bg-stone-800 transition-colors disabled:opacity-50"
            >
              {loading ? 'Curating Info...' : 'History & Insights (AI)'}
            </button>
          ) : (
            <div className="bg-orange-50 p-4 rounded-lg animate-fade-in">
              <p className="text-xs text-stone-700 italic">"{insight}"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DishCard;
