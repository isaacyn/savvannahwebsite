
import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getDishInsight(dishName: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Tell me about the history and cultural significance of the Kenyan dish "${dishName}" in 3 sentences.`,
        config: {
          temperature: 0.7,
        },
      });
      return response.text;
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "Unable to fetch dish details at the moment. Please try again later.";
    }
  }

  async suggestPairing(dishName: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `What is the best drink or side dish to pair with "${dishName}" in a traditional Kenyan setting? Respond in JSON format.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              pairing: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["pairing", "reason"]
          }
        },
      });
      return JSON.parse(response.text.trim());
    } catch (error) {
      console.error("Gemini API Error:", error);
      return { pairing: "Chai Tea", reason: "A classic Kenyan accompaniment." };
    }
  }
}

export const geminiService = new GeminiService();
